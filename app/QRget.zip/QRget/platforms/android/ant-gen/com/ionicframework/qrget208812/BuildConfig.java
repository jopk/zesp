/** Automatically generated file. DO NOT MODIFY */
package com.ionicframework.qrget208812;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}